
abstract class Routes {
  static const posts = '/posts';
  static const newPost = '/posts/new';
}

class AppPages {
  static final pages = [
    // GetPage(
    //   name: Routes.posts,
    //   page: () => const PostsView(),
    //   binding: PostsBinding(),
    // ),
    // GetPage(
    //   name: Routes.newPost,
    //   page: () => const PostFormView(),
    // ),
  ];
}
