import 'package:get/get.dart';

class InitialBindings extends Bindings {

  @override
  void dependencies() {
    // Get.put<ApiClient>(ApiClient(), permanent: true);
    // Get.lazyPut<PostRepository>(() => PostRepository(Get.find()), fenix: true);
  }
}